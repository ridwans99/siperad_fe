<?php $__env->startSection('container'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4"><?php echo e($title); ?></h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a> > <a
                        href="<?php echo e(route('jam.index')); ?>">Data Jam</a> > <?php echo e($title); ?></li>
            </ol>
            <div class="card mb-4">
                <div class="card-body">
                    <h6>Berikut adalah form <?php echo e(Str::lower($title)); ?>.</h6>
                </div>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <div class="alert-title">
                        <h4>Whoops!</h4>
                    </div>
                    There are some problems with your input.
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    <?php echo e($title); ?>

                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('jam.update', $data->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group mb-2">
                            
                            <input type="hidden" class="form-control" name="id" id="id"
                                value="<?php echo e($data->id); ?>">
                        </div>
                        <div class="form-group mb-2">
                            <label for="time">Jam</label>
                            <input type="time" class="form-control" id="appointment" name="jam"
                                value="<?php echo e($data->jam); ?>" min="00:00" max="23:00" required>
                        </div>
                </div>
                <button type="submit" class="btn btn-primary">Ubah</button>
                </form>
            </div>
        </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/admin/jam/edit.blade.php ENDPATH**/ ?>
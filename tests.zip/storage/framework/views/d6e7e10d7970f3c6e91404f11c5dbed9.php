

<?php $__env->startSection('container'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4"><?php echo e($title); ?></h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a> > <?php echo e($title); ?>

                </li>
            </ol>

            <form method="GET" class="mb-4">
                <div class="row">
                    <div class="col-md-3">
                        <select name="hari" class="form-select">
                            <option value="">-- Pilih Hari --</option>
                            <?php $__currentLoopData = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($h); ?>" <?php echo e(request('hari') == $h ? 'selected' : ''); ?>>
                                    <?php echo e($h); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="ruang" class="form-select">
                            <option value="">-- Pilih Ruangan --</option>
                            <?php $__currentLoopData = $ruanganList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($r); ?>" <?php echo e(request('ruang') == $r ? 'selected' : ''); ?>>
                                    <?php echo e($r); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="<?php echo e(route('jadwal-ruangan.view')); ?>" class="btn btn-secondary">Reset</a>
                    </div>
                </div>
            </form>

            <div class="card mb-4 text-center">
                <div class="card-body">
                    <h6>
                        Jadwal Hari <?php echo e(request('hari') ? ucfirst(request('hari')) : 'Senin'); ?>

                    </h6>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-body table-responsive">
                    <table class="table table-bordered text-center">
                        <thead class="table-light">
                            <tr>
                                <th>RUANG</th>
                                <?php $__currentLoopData = $jamHeaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($jam); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ruanganList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><strong><?php echo e($ruang); ?></strong></td>
                                    <?php $__currentLoopData = $jamHeaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo $matrix[$ruang][$jam] ?? '-'; ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/admin/jadwal-ruangan/view.blade.php ENDPATH**/ ?>
<?php $__env->startSection('container'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
        <div class="row">
            <div class="col-xl-12">
                <div class="border border-success rounded px-3 pt-3 mb-4">
                    <h3 class="text-success mb-4">Selamat Datang, <b>Administrator</b></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-6">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between">
                        <div>
                            <i class="fas fa-box me-1"></i>
                            History Peminjaman Alat
                        </div>
                        <div>
                            <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-sm btn-primary">Akses</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table id="datatablesSimple">
                            <thead>
                                <tr>
                                    <th>Peminjam</th>
                                    <th>Tgl Pinjam</th>
                                    <th>Alat yang dipinjam</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($b->nama_peminjam); ?></td>
                                        <td><?php echo e($b->tgl_peminjaman); ?></td>
                                        <td><?php echo e($b->barang['nama_barang']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between">
                        <div>
                            <i class="fas fa-house me-1"></i>
                            History Peminjaman Ruang
                        </div>
                        <div>
                            <a href="<?php echo e(route('ruang.index')); ?>" class="btn btn-sm btn-primary">Akses</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table id="datatablesSimple1">
                            <thead>
                                <tr>
                                    <th>Peminjam</th>
                                    <th>Tgl Pinjam</th>
                                    <th>Ruang yang dipinjam</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($r->nama_peminjam); ?></td>
                                        <td><?php echo e($r->tgl_peminjaman); ?></td>
                                        <td><?php echo e($r->ruang['nama_ruang']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
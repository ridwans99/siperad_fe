
<?php $__env->startSection('content'); ?>
    <?php if(session('alert')): ?>
        <script>
            Swal.fire({
                title: '<?php echo e(session('alert.title')); ?>',
                text: '<?php echo e(session('alert.text')); ?>',
                icon: '<?php echo e(session('alert.icon')); ?>',
                confirmButtonText: 'OK'
            });
        </script>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <div class="alert-title">
                <h4>Whoops!</h4>
            </div>
            There are some problems with your input.
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="container">
        <div class="content pt-4 pt-lg-0">
            </br></br>
            <h5>FORM PEMINJAMAN ALAT</h5>
            </br>
            <form action="<?php echo e(route('user.peminjaman-alat.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                
                <div class="mb-3">
                    <label class="form-label">Tanggal Peminjaman</label>
                    <input type="date" name="tgl_peminjaman" class="form-control" id="">
                </div>
                <div class="mb-3">
                    <label class="form-label">Nama Peminjam</label>
                    <input type="text" name="nama_peminjam" class="form-control" id=""
                        value="<?php echo e(auth()->user()->name); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">NIM Peminjam</label>
                    <input type="text" name="nim" class="form-control" id=""
                        value="<?php echo e(auth()->user()->username); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Nomor Hp</label>
                    <input type="text" name="no_hp" class="form-control" id="">
                </div>
                <div class="mb-3">
                    <label for="prodi_id" class="form-label">Prodi</label>
                    <select class="form-select" name="prodi_id" required>
                        <option selected disabled>Pilih Prodi</option>
                        <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?> " <?php if(auth()->user()->prodi_id == $p->id): ?> selected <?php endif; ?>>
                                <?php echo e($p->nama_prodi); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="angkatan_id">Angkatan</label>
                    <select class="form-select" name="angkatan_id">
                        <option selected disabled>Pilih Angkatan</option>
                        <?php $__currentLoopData = $angkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($a->id); ?>"  <?php if(auth()->user()->angkatan_id == $a->id): ?> selected <?php endif; ?>><?php echo e($a->angkatan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="matkul_id">Mata Kuliah</label>
                    <select class="form-select" name="matkul_id">
                        <option selected disabled>Mata Kuliah</option>
                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>"><?php echo e($m->mata_kuliah); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="dosen_id">Nama Dosen</label>
                    <select class="form-select" name="dosen_id">
                        <option selected disabled>Nama Dosen</option>
                        <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nd->id); ?>"><?php echo e($nd->nama_dosen); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="barang_id" class="form-label">Nama Alat</label>
                    <input type="text" class="form-control" value="<?php echo e($barang->nama_barang); ?>" disabled>
                    <input type="hidden" name="barang_id" value="<?php echo e($barang->id); ?>">
                </div>

                
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
    </form>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/user/form/peminjamanalat.blade.php ENDPATH**/ ?>
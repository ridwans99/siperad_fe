<?php $__env->startSection('container'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4"><?php echo e($title); ?></h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a> > <a
                        href="<?php echo e(route('prodi.index')); ?>">Data Prodi</a> > <?php echo e($title); ?></li>
            </ol>
            <div class="card mb-4">
                <div class="card-body">
                    <h6>Berikut adalah form <?php echo e(Str::lower($title)); ?>.</h6>
                </div>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <div class="alert-title">
                        <h4>Whoops!</h4>
                    </div>
                    There are some problems with your input.
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    <?php echo e($title); ?>

                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('prodi.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group mb-2">
                            <label for="nama_prodi">Nama Program Studi</label>
                            <input type="text" class="form-control" name="nama_prodi" id="nama_prodi">
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/admin/prodi/create.blade.php ENDPATH**/ ?>
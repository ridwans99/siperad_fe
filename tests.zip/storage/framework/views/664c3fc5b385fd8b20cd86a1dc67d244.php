

<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4 pt-4 pt-lg-5">
            
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-4">
                                <label for="hari" class="form-label">Hari</label>
                                <select name="hari" id="hari" class="form-select">
                                    <option value="">-- Pilih Hari --</option>
                                    <?php $__currentLoopData = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($h); ?>" <?php echo e(request('hari') == $h ? 'selected' : ''); ?>>
                                            <?php echo e($h); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label for="ruang" class="form-label">Ruangan</label>
                                <select name="ruang" id="ruang" class="form-select">
                                    <option value="">-- Pilih Ruangan --</option>
                                    <?php $__currentLoopData = $ruanganList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($r); ?>" <?php echo e(request('ruang') == $r ? 'selected' : ''); ?>>
                                            <?php echo e($r); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary">Filter</button>
                                <a href="<?php echo e(route('user.lihatjadwal')); ?>" class="btn btn-secondary">Reset</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            
            <div class="card mb-3 text-center">
                <div class="card-body py-3">
                    <h5 class="mb-0">
                        Jadwal Hari <strong><?php echo e(request('hari') ? ucfirst(request('hari')) : 'Senin'); ?></strong>
                    </h5>
                </div>
            </div>

            
            <div class="card">
                <div class="card-body table-responsive">
                    <table class="table table-bordered text-center align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>RUANG</th>
                                <?php $__currentLoopData = $jamHeaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($jam); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ruanganList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><strong><?php echo e($ruang); ?></strong></td>
                                    <?php $__currentLoopData = $jamHeaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo $matrix[$ruang][$jam] ?? '-'; ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/user/kalender/view.blade.php ENDPATH**/ ?>
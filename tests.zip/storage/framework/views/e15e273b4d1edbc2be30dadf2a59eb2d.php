<?php $__env->startSection('container'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4"><?php echo e($title); ?></h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a> > <?php echo e($title); ?>

                </li>
            </ol>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <div class="card mb-4">
                <div class="card-body">
                    <h6>Berikut adalah <?php echo e(Str::lower($title)); ?> terupdate. </h6>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between">
                    <div>
                        <i class="fas fa-table me-1"></i>
                        <?php echo e($title); ?>

                    </div>
                    <div>
                        <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-sm btn-primary">Tambah data</a>
                    </div>
                </div>
                <div class="card-body">
                    <table id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Alat</th>
                                <th>Stok</th>
                                <th>Deskripsi</th>
                                <th>Status Alat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($d->nama_barang); ?></td>
                                    <td><?php echo e($d->stok); ?></td>

                                    <td><?php echo $d->deskripsi_barang; ?></td>
                                    <td>
                                        <?php if($d->status_barang == 1): ?>
                                            <button class="btn btn-sm btn-success" disabled>Tersedia</button>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-secondary" disabled>Tidak Tersedia</button>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('barang.destroy', $d->id)); ?>" class="btn btn-sm btn-danger"
                                            data-confirm-delete="true"><i class="fas fa-trash"></i></a>
                                        
                                        <a href="<?php echo e(route('barang.edit', $d->id)); ?>" class="btn btn-sm btn-primary"><i
                                                class="fas fa-pencil"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/admin/barang/index.blade.php ENDPATH**/ ?>
<footer class="py-4 bg-light mt-auto">
  <div class="container-fluid px-4">
      <div class="d-flex align-items-center justify-content-between small">
          <div class="text-muted">Copyright &copy; UNJ</div>
          
      </div>
  </div>
</footer><?php /**PATH D:\Skripsi\siperad\resources\views/admin/page/partials/footer.blade.php ENDPATH**/ ?>
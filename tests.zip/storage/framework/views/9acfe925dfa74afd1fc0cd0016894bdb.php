
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="content pt-4 pt-lg-0"></br></br>
            <h3 class="panel-title">Data Peminjaman Alat</h3>
            <div class="d-flex justify-content-end mb-3">
                <form class="d-flex" method="GET" action="<?php echo e(route('user.historypeminjamanalat')); ?>">
                    <input class="form-control me-2" name="cari" type="text" placeholder="Cari Nama/NIM..."
                        value="<?php echo e(request('cari')); ?>">
                    <button class="btn btn-outline-primary" type="submit">Cari</button>
                </form>
            </div>
            <div class="panel-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Tanggal Peminjaman</th>
                            <th>Nama </th>
                            <th>NIM</th>
                            <th>No Hp</th>
                            <th>Prodi</th>
                            <th>Angkatan</th>
                            <th>Matkul</th>
                            <th>Dosen</th>
                            <th>Barang yang Dipinjam</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjamanalat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($peminjamanalat->tgl_peminjaman); ?></td>
                                <td><?php echo e($peminjamanalat->nama_peminjam); ?></td>
                                <td><?php echo e($peminjamanalat->nim); ?></td>
                                <td><?php echo e($peminjamanalat->no_hp); ?></td>
                                <td><?php echo e($peminjamanalat->prodi['nama_prodi']); ?></td>
                                <td><?php echo e($peminjamanalat->angkatan['angkatan']); ?></td>
                                <td><?php echo e($peminjamanalat->matkul['mata_kuliah']); ?></td>
                                <td><?php echo e($peminjamanalat->dosen['nama_dosen']); ?></td>
                                <td><?php echo e($peminjamanalat->barang['nama_barang']); ?></td>
                                <td>
                                    <?php if($peminjamanalat->status_peminjaman == 1): ?>
                                        <button class="btn btn-sm btn-success" disabled>Sudah dikembalikan</button>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-secondary" disabled>Belum dikembalikan</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/user/data/peminjamanalat.blade.php ENDPATH**/ ?>
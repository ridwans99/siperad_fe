
<?php $__env->startSection('content'); ?>
    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <?php if(session('alert')): ?>
            
            <script>
                Swal.fire({
                    title: '<?php echo e(session('alert.title')); ?>',
                    text: '<?php echo e(session('alert.text')); ?>',
                    icon: '<?php echo e(session('alert.icon')); ?>',
                    confirmButtonText: 'OK'
                });
            </script>
        <?php endif; ?>

        <div class="container">
            <div class="row">
                <div class="row">
                    <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center"
                        data-aos="fade-up">
                        <div>
                            <h1>Selamat Datang di Sistem Peminjaman Ruang dan Alat</h1>
                            <h2>Rumpun Matematika Universitas Negeri Jakarta</h2>

                        </div>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left">
                        <img src="<?php echo e(asset('frontend/assets/img/hero-img.png')); ?>" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </div>

    </section><!-- End Hero -->

    <main id="main">

        <!-- ======= Tatacara Section ======= -->
        <section id="tatacara" class="tatacara">
            <div class="container">

                <div class="row">
                    <div class="col-lg-6" data-aos="zoom-in">
                        <img src="<?php echo e(asset('frontend/assets/img/about.jpg')); ?>" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-6 d-flex flex-column justify-contents-center" data-aos="fade-left">
                        <div class="content pt-4 pt-lg-0">
                            <h3>Tentang Sistem</h3>
                            <p class="font-italic">
                                Sistem informasi ini dibuat untuk mahasiswa dan staff Universitas
                                Negeri Jakarta.
                                Sistem dapat melayani peminjaman ruang atau alat untuk keperluan perkuliahan, organisasi,
                                dan lainnya.
                                Tata cara meggunakan sistem yang perlu diperhatikan:
                            </p>
                            <ul>
                                <li><i class="icofont-check-circled"></i> Sign In</li>
                                <li><i class="icofont-check-circled"></i> Baca Peraturan</li>
                                <li><i class="icofont-check-circled"></i> Mengisi Form Peminjaman</li>
                                <li><i class="icofont-check-circled"></i> Tunggu Status Peminjaman</li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </section><!-- End Tatacara Section -->

        <!-- ======= Fasilitas Section ======= -->
        
        <!-- End Fasilitas Section -->

        <!-- ======= Cta Section ======= -->
        
        <!-- End Cta Section -->

        <!-- ======= Cta Section ======= -->
        
        <!-- End Cta Section -->

        <!-- ======= F.A.Q Section ======= -->
        
        <!-- End Frequently Asked Questions Section -->
    </main><!-- End #main -->
    

<?php echo $__env->make('user.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/user/home.blade.php ENDPATH**/ ?>
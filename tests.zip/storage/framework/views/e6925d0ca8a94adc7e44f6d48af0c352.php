
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="content pt-4 pt-lg-0"></br></br>
            <h3 class="panel-title">Data Peminjaman Ruang</h3>
            <div class="d-flex justify-content-end mb-3">
                <form class="d-flex" method="GET" action="<?php echo e(route('user.historypeminjamanruang')); ?>">
                    <input class="form-control me-2" name="cari" type="text" placeholder="Cari Nama/NIM..."
                        value="<?php echo e(request('cari')); ?>">
                    <button class="btn btn-outline-primary" type="submit">Cari</button>
                </form>
            </div>
            <div class="panel-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Tanggal Peminjaman</th>
                            <th>Nama </th>
                            <th>Matkul</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Dosen</th>
                            <th>Prodi</th>
                            <th>Angkatan</th>
                            <th>Ruang yang Dipinjam</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peminjamanruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($peminjamanruang->tgl_peminjaman); ?></td>
                                <td><?php echo e($peminjamanruang->nama_peminjam); ?></td>
                                <td><?php echo e($peminjamanruang->matkul['mata_kuliah']); ?></td>
                                <td><?php echo e(substr($peminjamanruang->jamx['jam'], 0, 5)); ?></td>
                                <td><?php echo e(substr($peminjamanruang->jamy['jam'], 0, 5)); ?></td>
                                <td><?php echo e($peminjamanruang->dosen['nama_dosen']); ?></td>
                                <td><?php echo e($peminjamanruang->prodi['nama_prodi']); ?></td>
                                <td><?php echo e($peminjamanruang->angkatan['angkatan']); ?></td>
                                <td><?php echo e($peminjamanruang->ruang['nama_ruang']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/user/data/peminjamanruang.blade.php ENDPATH**/ ?>
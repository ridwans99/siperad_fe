

<?php $__env->startSection('content'); ?>
    <main class="py-4">
        <div class="container">
            <h3 class="text-center mb-4">Kalender Jadwal Ruangan</h3>
            <form method="GET" class="mb-3 text-center">
                <label for="filterRuang" class="me-2">Pilih Ruangan:</label>
                <select name="ruang" id="filterRuang" onchange="this.form.submit()" class="form-select d-inline w-auto">
                    <option value="">Semua Ruangan</option>
                    <?php $__currentLoopData = $ruanganList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($r->nama_ruang); ?>" <?php echo e(request('ruang') == $r->nama_ruang ? 'selected' : ''); ?>>
                            <?php echo e($r->nama_ruang); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
            <div id='calendar'></div>
        </div>



        <!-- Modal Form -->
        <div class="modal fade" id="peminjamanModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg"> 
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalLabel">Form Peminjaman</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                    </div>
                    <form action="<?php echo e(route('user.peminjaman-ruang.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo e(csrf_field()); ?>

                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Tanggal</label>
                                <input type="text" name="tgl_peminjaman" id="tgl_peminjaman" class="form-control"
                                    readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Nama Peminjam</label>
                                <input type="text" name="nama_peminjam" class="form-control"
                                    value="<?php echo e(auth()->user()->name); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="matkul_id">Mata Kuliah</label>
                                <select class="form-select" name="matkul_id">
                                    <option selected disabled>Mata Kuliah</option>
                                    <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($m->id); ?>"><?php echo e($m->mata_kuliah); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group mb-2">
                                <label for="time">Jam Mulai</label>
                                <select class="form-select" name="jam_mulai_id">
                                    <option selected disabled>Jam Mulai</option>
                                    <?php $__currentLoopData = $jam_mulai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($jm->id); ?>"><?php echo e(substr($jm->jam, 0, 5)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group mb-2">
                                <label for="time">Jam Selesai</label>
                                <select class="form-select" name="jam_selesai_id">
                                    <option selected disabled>Jam Selesai</option>
                                    <?php $__currentLoopData = $jam_selesai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $js): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($js->id); ?>"><?php echo e(substr($js->jam, 0, 5)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="dosen_id">Nama Dosen</label>
                                <select class="form-select" name="dosen_id">
                                    <option selected disabled>Nama Dosen</option>
                                    <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($nd->id); ?>"><?php echo e($nd->nama_dosen); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="prodi_id" class="form-label">Prodi</label>
                                <select class="form-select" name="prodi_id" required>
                                    <option selected disabled>Pilih Prodi</option>
                                    <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>"
                                            <?php if(auth()->user()->prodi_id == $p->id): ?> selected <?php endif; ?>><?php echo e($p->nama_prodi); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="angkatan_id">Angkatan</label>
                                <select class="form-select" name="angkatan_id">
                                    <option selected disabled>Pilih Angkatan</option>
                                    <?php $__currentLoopData = $angkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($a->id); ?>"
                                            <?php if(auth()->user()->angkatan_id == $a->id): ?> selected <?php endif; ?>><?php echo e($a->angkatan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="ruang_id" class="form-label">Ruangan</label>
                                <select class="form-select" name="ruang_id" <?php echo e(request('ruang') ? 'disabled' : ''); ?>>
                                    <option selected disabled>Pilih Ruangan</option>
                                    <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($r->id); ?>"
                                            <?php echo e(request('ruang') == $r->nama_ruang ? 'selected' : ''); ?>>
                                            <?php echo e($r->nama_ruang); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if(request('ruang')): ?>
                                    <?php
                                        $selectedRuang = $ruang->firstWhere('nama_ruang', request('ruang'));
                                    ?>
                                    <input type="hidden" name="ruang_id" value="<?php echo e($selectedRuang->id ?? ''); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                            <button type="submit" class="btn btn-primary">Ajukan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- FullCalendar Styles -->
        <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">

        <!-- FullCalendar Scripts -->
        <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const calendarEl = document.getElementById('calendar');

                const calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    locale: 'id',
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay'
                    },
                    events: <?php echo json_encode($events, 15, 512) ?>,

                    // Klik tanggal = buka tampilan jam harian
                    dateClick: function(info) {
                        calendar.changeView('timeGridDay', info.dateStr);
                    },

                    eventClick: function(info) {
                        const date = info.event.startStr.split("T")[0];
                        document.getElementById('tgl_peminjaman').value = date;

                        // Hanya buka form jika slot kosong (misalnya title = 'Kosong')
                        if (info.event.title === 'Kosong') {
                            const modal = new bootstrap.Modal(document.getElementById('peminjamanModal'));
                            modal.show();
                        } else {
                            alert("Slot ini sudah terisi jadwal!");
                        }
                    },

                    selectable: true,
                    select: function(info) {
                        // Ambil tanggal, jam mulai, dan jam selesai dari event drag
                        const start = new Date(info.start);
                        const end = new Date(info.end);

                        // Format: YYYY-MM-DD
                        const dateStr = start.toISOString().split('T')[0];

                        // Format: HH:MM
                        const jamMulai = start.toTimeString().substring(0, 5);
                        const jamSelesai = end.toTimeString().substring(0, 5);

                        // Set ke input tanggal
                        document.getElementById('tgl_peminjaman').value = dateStr;

                        // Cari dan set select option untuk jam mulai dan selesai
                        const jamMulaiSelect = document.querySelector('select[name="jam_mulai_id"]');
                        const jamSelesaiSelect = document.querySelector('select[name="jam_selesai_id"]');

                        // Cari option berdasarkan jam string
                        setSelectOptionByText(jamMulaiSelect, jamMulai);
                        setSelectOptionByText(jamSelesaiSelect, jamSelesai);



                        // Tampilkan modal
                        const modal = new bootstrap.Modal(document.getElementById('peminjamanModal'));
                        modal.show();
                    },

                    eventDidMount: function(info) {
                        if (info.event.title.startsWith('Matkul Pengganti')) {
                            info.el.style.backgroundColor = '#dc3545'; // merah
                        }

                        // if (info.event.title.startsWith('Jadwal Tetap')) {
                        //     info.el.style.backgroundColor = '#3788d8'; // biru
                        // }
                    },

                    slotMinTime: "00:00:00",
                    slotMaxTime: "23:00:00",
                    slotDuration: "01:00:00", // per jam
                    // snapDuration: "00:30:00",
                    allDaySlot: false,
                });

                calendar.render();

                function setSelectOptionByText(select, text) {
                    for (let i = 0; i < select.options.length; i++) {
                        if (select.options[i].text.trim() === text.trim()) {
                            select.selectedIndex = i;
                            break;
                        }
                    }
                }
            });
        </script>

        <style>
            #calendar {
                max-width: 1000px;
                margin: 0 auto;
            }
        </style>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Skripsi\siperad\resources\views/user/kalender/kalender.blade.php ENDPATH**/ ?>
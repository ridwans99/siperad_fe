<?php

use App\Http\Controllers\APIController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\RuangController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::controller(APIController::class)->group(function () {
    // Route::get('/get/alat', 'apigetAlat');
    // Route::get('/barang/tambah' , 'create')->name('barang.create');
    // Route::post('/post/alat', 'postAlat');
    // Route::get('/barang/edit/{id}', 'edit')->name('barang.edit');
    // Route::put('/barang/edit/{id}', 'update')->name('barang.update');
    // Route::delete('/barang/hapus/{id}', 'destroy')->name('barang.destroy');
    Route::get('/alat', [BarangController::class, 'apigetAlat']);
    Route::post('/alat', [BarangController::class, 'postAlat']);
    Route::put('/alat/{id}', [BarangController::class, 'updateAlat']);
    Route::delete('/alat/{id}', [BarangController::class, 'deleteAlat']);

    Route::get('/ruang', [RuangController::class, 'apigetRuang']);
    Route::post('/ruang', [RuangController::class, 'postRuang']);
    Route::put('/ruang/{id}', [RuangController::class, 'updateRuang']);
    Route::delete('/ruang/{id}', [RuangController::class, 'deleteRuang']);

    Route::get('/ruang', [RuangController::class, 'apigetRuang']);
    Route::post('/ruang', [RuangController::class, 'postRuang']);
    Route::put('/ruang/{id}', [RuangController::class, 'updateRuang']);
    Route::delete('/ruang/{id}', [RuangController::class, 'deleteRuang']);

    Route::get('/ruang', [RuangController::class, 'apigetRuang']);
    Route::post('/ruang', [RuangController::class, 'postRuang']);
    Route::put('/ruang/{id}', [RuangController::class, 'updateRuang']);
    Route::delete('/ruang/{id}', [RuangController::class, 'deleteRuang']);
});

<footer class="py-4 bg-light mt-auto">
  <div class="container-fluid px-4">
      <div class="d-flex align-items-center justify-content-between small">
          <div class="text-muted">Copyright &copy; UNJ</div>
          {{-- <div>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted by <span class="text-primary">...</span> & made with <i class="fas fa-heart"></i></span>
          </div> --}}
      </div>
  </div>
</footer>
@extends('user.layouts.frontend')

@section('content')
    <main class="py-4">
        <div class="container">
            <h3 class="text-center mb-3">Availability of Lecturer</h3>
            <div class="row">
                <div class="col-md-6">
                    {{-- LEFT COLUMN --}}
                    <div class="lecturer-box available">1. Ir. Fariani Hermin Indiyah, MT.</div>
                    <div class="lecturer-box unavailable">2. Dr. Ir. Bagus Sumargo, M.Si.</div>
                    <div class="lecturer-box unavailable">3. Dr. Makmuri, M.Si.</div>
                    <div class="lecturer-box unavailable">4. Prof. Dr. Wardani Rahayu, M.Si.</div>
                    <div class="lecturer-box unavailable">5. Dr. Pinta Deniyanti S, M.Si.</div>
                    <div class="lecturer-box unavailable">6. Dr. Ellis Salsabila, M.Si.</div>
                    <div class="lecturer-box available">7. Prof. Dr. Suyono, M.Si.</div>
                    <div class="lecturer-box text-success">Available</div>
                    <div class="lecturer-box unavailable">9. Drs. Sudarwanto, M.Si., DEA.</div>
                    <div class="lecturer-box unavailable">10. Drs. Mulyono, M.Kom.</div>
                    <div class="lecturer-box available">11. Dr. Dian Handayani, M.Si.</div>
                    <div class="lecturer-box unavailable">12. Dra. Widyanti Rahayu, M.Si.</div>
                    <div class="lecturer-box text-success">Available</div>
                    <div class="lecturer-box unavailable">14. Ratna Widyati, S.Si., M.Kom.</div>
                    <div class="lecturer-box unavailable">15. Med Irzal, M.Kom.</div>
                </div>
                <div class="col-md-6">
                    {{-- RIGHT COLUMN --}}
                    <div class="lecturer-box unavailable">16. Vera Maya Santi, M.Si.</div>
                    <div class="lecturer-box unavailable">17. Dr. Ria Arfiyah, M.Si.</div>
                    <div class="lecturer-box unavailable">18. Dwi Edi Dwi W, S.Pd., M.Si.</div>
                    <div class="lecturer-box unavailable">19. Lukman El Hakim, M.Pd.</div>
                    <div class="lecturer-box unavailable">20. Aris Hadiyan Wijaksana, M.Pd.</div>
                    <div class="lecturer-box unavailable">21. Ibnu Hadi, M.Si.</div>
                    <div class="lecturer-box available">22. Dwi Antari Wijayanti, M.Pd.</div>
                    <div class="lecturer-box unavailable">23. Dr. Yudi Mahatma, M.Si.</div>
                    <div class="lecturer-box unavailable">24. Meillasaari, S.Pd., M.Sc.</div>
                    <div class="lecturer-box unavailable">25. Dr. Puspita Sari, S.Pd., M.Sc.</div>
                    <div class="lecturer-box unavailable">26. Muhammad Eka S, M.Kom.</div>
                    <div class="lecturer-box unavailable">27. Bobby Agustine, M.Si.</div>
                    <div class="lecturer-box unavailable">28. Sri Rohmah R, S.Pd., M.Si.</div>
                    <div class="lecturer-box unavailable">29. Dania Siregar, S.Stat., M.Si.</div>
                    <div class="lecturer-box unavailable">30. Ari Hendarno, S.Pd., M.Kom.</div>
                </div>
            </div>

            {{-- BOTTOM SECTION --}}
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="lecturer-box unavailable">31. Dr. Mimi Nur Hajizah, M.Pd.</div>
                    <div class="lecturer-box unavailable">32. Tian Abdul Aziz, Ph.D.</div>
                    <div class="lecturer-box unavailable">33. Devi Eka W M, S.Pd., M.Si.</div>
                    <div class="lecturer-box unavailable">34. Qorry Meidianingsih, M.Si.</div>
                    <div class="lecturer-box unavailable">35. Leny Dhiani Haeruman, M.Pd.</div>
                    <div class="lecturer-box unavailable">36. Dr. Flavia A H, S.Pd., M.Si.</div>
                    <div class="lecturer-box unavailable">37. Faroh Ladaya, M.Si.</div>
                    <div class="lecturer-box unavailable">38. Dr. Anny Sovia, S.Si., M.Pd.</div>
                    <div class="lecturer-box unavailable">39. Agus Agung P, S.Si., M.Pd.</div>
                    <div class="lecturer-box unavailable">40. Nurashri Partasvii, S.Si., M.Pd.</div>
                </div>
            </div>
        </div>

        <style>
            .lecturer-box {
                height: 32px;
                line-height: 32px;
                padding: 0 10px;
                margin: 2px 0;
                color: white;
                border-radius: 4px;
                font-size: 14px;
            }

            .available {
                background-color: #28a745;
            }

            .unavailable {
                background-color: #dc3545;
            }
        </style>
    </main>
@endsection

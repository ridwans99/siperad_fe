@extends('user.layouts.frontend')

@section('content')
    <main class="py-4">
        <div class="container">
            <h3 class="text-center mb-4">Kalender Jadwal Ruangan</h3>
            <form method="GET" class="mb-3 text-center">
                <label for="filterRuang" class="me-2">Pilih Ruangan:</label>
                <select name="ruang" id="filterRuang" onchange="this.form.submit()" class="form-select d-inline w-auto">
                    <option value="">Semua Ruangan</option>
                    @foreach ($ruanganList as $r)
                        <option value="{{ $r->nama_ruang }}" {{ request('ruang') == $r->nama_ruang ? 'selected' : '' }}>
                            {{ $r->nama_ruang }}
                        </option>
                    @endforeach
                </select>
            </form>
            <div id='calendar'></div>
        </div>



        <!-- Modal Form -->
        <div class="modal fade" id="peminjamanModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg"> {{-- Perbesar modal --}}
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalLabel">Form Peminjaman</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                    </div>
                    <form action="{{ route('user.peminjaman-ruang.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        {{ csrf_field() }}
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">Tanggal</label>
                                <input type="text" name="tgl_peminjaman" id="tgl_peminjaman" class="form-control"
                                    readonly>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Nama Peminjam</label>
                                <input type="text" name="nama_peminjam" class="form-control"
                                    value="{{ auth()->user()->name }}" required>
                            </div>
                            <div class="mb-3">
                                <label for="matkul_id">Mata Kuliah</label>
                                <select class="form-select" name="matkul_id">
                                    <option selected disabled>Mata Kuliah</option>
                                    @foreach ($matkul as $m)
                                        <option value="{{ $m->id }}">{{ $m->mata_kuliah }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group mb-2">
                                <label for="time">Jam Mulai</label>
                                <select class="form-select" name="jam_mulai_id">
                                    <option selected disabled>Jam Mulai</option>
                                    @foreach ($jam_mulai as $jm)
                                        <option value="{{ $jm->id }}">{{ substr($jm->jam, 0, 5) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group mb-2">
                                <label for="time">Jam Selesai</label>
                                <select class="form-select" name="jam_selesai_id">
                                    <option selected disabled>Jam Selesai</option>
                                    @foreach ($jam_selesai as $js)
                                        <option value="{{ $js->id }}">{{ substr($js->jam, 0, 5) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="dosen_id">Nama Dosen</label>
                                <select class="form-select" name="dosen_id">
                                    <option selected disabled>Nama Dosen</option>
                                    @foreach ($dosen as $nd)
                                        <option value="{{ $nd->id }}">{{ $nd->nama_dosen }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="prodi_id" class="form-label">Prodi</label>
                                <select class="form-select" name="prodi_id" required>
                                    <option selected disabled>Pilih Prodi</option>
                                    @foreach ($prodi as $p)
                                        <option value="{{ $p->id }}"
                                            @if (auth()->user()->prodi_id == $p->id) selected @endif>{{ $p->nama_prodi }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="angkatan_id">Angkatan</label>
                                <select class="form-select" name="angkatan_id">
                                    <option selected disabled>Pilih Angkatan</option>
                                    @foreach ($angkatan as $a)
                                        <option value="{{ $a->id }}"
                                            @if (auth()->user()->angkatan_id == $a->id) selected @endif>{{ $a->angkatan }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="ruang_id" class="form-label">Ruangan</label>
                                <select class="form-select" name="ruang_id" {{ request('ruang') ? 'disabled' : '' }}>
                                    <option selected disabled>Pilih Ruangan</option>
                                    @foreach ($ruang as $r)
                                        <option value="{{ $r->id }}"
                                            {{ request('ruang') == $r->nama_ruang ? 'selected' : '' }}>
                                            {{ $r->nama_ruang }}
                                        </option>
                                    @endforeach
                                </select>

                                @if (request('ruang'))
                                    @php
                                        $selectedRuang = $ruang->firstWhere('nama_ruang', request('ruang'));
                                    @endphp
                                    <input type="hidden" name="ruang_id" value="{{ $selectedRuang->id ?? '' }}">
                                @endif
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                            <button type="submit" class="btn btn-primary">Ajukan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- FullCalendar Styles -->
        <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">

        <!-- FullCalendar Scripts -->
        <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const calendarEl = document.getElementById('calendar');

                const calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    locale: 'id',
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay'
                    },
                    events: @json($events),

                    // Klik tanggal = buka tampilan jam harian
                    dateClick: function(info) {
                        calendar.changeView('timeGridDay', info.dateStr);
                    },

                    eventClick: function(info) {
                        const date = info.event.startStr.split("T")[0];
                        document.getElementById('tgl_peminjaman').value = date;

                        // Hanya buka form jika slot kosong (misalnya title = 'Kosong')
                        if (info.event.title === 'Kosong') {
                            const modal = new bootstrap.Modal(document.getElementById('peminjamanModal'));
                            modal.show();
                        } else {
                            alert("Slot ini sudah terisi jadwal!");
                        }
                    },

                    selectable: true,
                    select: function(info) {
                        // Ambil tanggal, jam mulai, dan jam selesai dari event drag
                        const start = new Date(info.start);
                        const end = new Date(info.end);

                        // Format: YYYY-MM-DD
                        const dateStr = start.toISOString().split('T')[0];

                        // Format: HH:MM
                        const jamMulai = start.toTimeString().substring(0, 5);
                        const jamSelesai = end.toTimeString().substring(0, 5);

                        // Set ke input tanggal
                        document.getElementById('tgl_peminjaman').value = dateStr;

                        // Cari dan set select option untuk jam mulai dan selesai
                        const jamMulaiSelect = document.querySelector('select[name="jam_mulai_id"]');
                        const jamSelesaiSelect = document.querySelector('select[name="jam_selesai_id"]');

                        // Cari option berdasarkan jam string
                        setSelectOptionByText(jamMulaiSelect, jamMulai);
                        setSelectOptionByText(jamSelesaiSelect, jamSelesai);



                        // Tampilkan modal
                        const modal = new bootstrap.Modal(document.getElementById('peminjamanModal'));
                        modal.show();
                    },

                    eventDidMount: function(info) {
                        if (info.event.title.startsWith('Matkul Pengganti')) {
                            info.el.style.backgroundColor = '#dc3545'; // merah
                        }

                        // if (info.event.title.startsWith('Jadwal Tetap')) {
                        //     info.el.style.backgroundColor = '#3788d8'; // biru
                        // }
                    },

                    slotMinTime: "00:00:00",
                    slotMaxTime: "23:00:00",
                    slotDuration: "01:00:00", // per jam
                    // snapDuration: "00:30:00",
                    allDaySlot: false,
                });

                calendar.render();

                function setSelectOptionByText(select, text) {
                    for (let i = 0; i < select.options.length; i++) {
                        if (select.options[i].text.trim() === text.trim()) {
                            select.selectedIndex = i;
                            break;
                        }
                    }
                }
            });
        </script>

        <style>
            #calendar {
                max-width: 1000px;
                margin: 0 auto;
            }
        </style>
    </main>
@endsection

@extends('user.layouts.frontend')
@section('content')
    <div class="container">
        <div class="content pt-4 pt-lg-0"></br></br>
            <h3 class="panel-title">Data Peminjaman Alat</h3>
            <div class="d-flex justify-content-end mb-3">
                <form class="d-flex" method="GET" action="{{ route('user.historypeminjamanalat') }}">
                    <input class="form-control me-2" name="cari" type="text" placeholder="Cari Nama/NIM..."
                        value="{{ request('cari') }}">
                    <button class="btn btn-outline-primary" type="submit">Cari</button>
                </form>
            </div>
            <div class="panel-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Tanggal Peminjaman</th>
                            <th>Nama </th>
                            <th>NIM</th>
                            <th>No Hp</th>
                            <th>Prodi</th>
                            <th>Angkatan</th>
                            <th>Matkul</th>
                            <th>Dosen</th>
                            <th>Barang yang Dipinjam</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data as $peminjamanalat)
                            <tr>
                                <td>{{ $peminjamanalat->tgl_peminjaman }}</td>
                                <td>{{ $peminjamanalat->nama_peminjam }}</td>
                                <td>{{ $peminjamanalat->nim }}</td>
                                <td>{{ $peminjamanalat->no_hp }}</td>
                                <td>{{ $peminjamanalat->prodi['nama_prodi'] }}</td>
                                <td>{{ $peminjamanalat->angkatan['angkatan'] }}</td>
                                <td>{{ $peminjamanalat->matkul['mata_kuliah'] }}</td>
                                <td>{{ $peminjamanalat->dosen['nama_dosen'] }}</td>
                                <td>{{ $peminjamanalat->barang['nama_barang'] }}</td>
                                <td>
                                    @if ($peminjamanalat->status_peminjaman == 1)
                                        <button class="btn btn-sm btn-success" disabled>Sudah dikembalikan</button>
                                    @else
                                        <button class="btn btn-sm btn-secondary" disabled>Belum dikembalikan</button>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

@stop

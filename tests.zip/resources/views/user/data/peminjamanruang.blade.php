@extends('user.layouts.frontend')
@section('content')
    <div class="container">
        <div class="content pt-4 pt-lg-0"></br></br>
            <h3 class="panel-title">Data Peminjaman Ruang</h3>
            <div class="d-flex justify-content-end mb-3">
                <form class="d-flex" method="GET" action="{{ route('user.historypeminjamanruang') }}">
                    <input class="form-control me-2" name="cari" type="text" placeholder="Cari Nama/NIM..."
                        value="{{ request('cari') }}">
                    <button class="btn btn-outline-primary" type="submit">Cari</button>
                </form>
            </div>
            <div class="panel-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Tanggal Peminjaman</th>
                            <th>Nama </th>
                            <th>Matkul</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Dosen</th>
                            <th>Prodi</th>
                            <th>Angkatan</th>
                            <th>Ruang yang Dipinjam</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data as $peminjamanruang)
                            <tr>
                                <td>{{ $peminjamanruang->tgl_peminjaman }}</td>
                                <td>{{ $peminjamanruang->nama_peminjam }}</td>
                                <td>{{ $peminjamanruang->matkul['mata_kuliah'] }}</td>
                                <td>{{ substr($peminjamanruang->jamx['jam'], 0, 5) }}</td>
                                <td>{{ substr($peminjamanruang->jamy['jam'], 0, 5) }}</td>
                                <td>{{ $peminjamanruang->dosen['nama_dosen'] }}</td>
                                <td>{{ $peminjamanruang->prodi['nama_prodi'] }}</td>
                                <td>{{ $peminjamanruang->angkatan['angkatan'] }}</td>
                                <td>{{ $peminjamanruang->ruang['nama_ruang'] }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

@stop

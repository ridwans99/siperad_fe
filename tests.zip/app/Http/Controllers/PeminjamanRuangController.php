<?php

namespace App\Http\Controllers;

use App\Models\Angkatan;
use App\Models\Jam;
use App\Models\MataKuliah;
use App\Models\NamaDosen;
use App\Models\PeminjamanRuang;
use App\Models\Prodi;
use Illuminate\Http\Request;
use App\Models\Ruang;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;

class PeminjamanRuangController extends Controller
{
    public function index(Request $request)
    {
        $data = PeminjamanRuang::with(['Prodi', 'Angkatan', 'Ruang', 'Matkul', 'Dosen', 'Jamx', 'Jamy'])->get();
        $title = 'Delete Peminjaman Ruangan!';
        $text = "Are you sure you want to delete?";
        confirmDelete($title, $text);
        if (auth()->user()->type == '1') {
            return view('admin/peminjaman-ruang/index', [
                'title' => 'Data Peminjaman Ruang',
                'data' => $data
            ]);
        } else {
            $query = PeminjamanRuang::with(['Prodi', 'Angkatan', 'Ruang', 'Matkul', 'Dosen', 'Jamx', 'Jamy'])
                ->where('nama_peminjam', auth()->user()->name);

            if ($request->has('cari')) {
                $query->where(function ($q) use ($request) {
                    $q->where('nama_peminjam', 'LIKE', '%' . $request->cari . '%')
                        ->orWhere('nama_peminjam', 'LIKE', '%' . $request->cari . '%');
                });
            }

            // if ($request->has('cari')) {
            //     $data = PeminjamanRuang::where('nama_peminjam', 'LIKE', '%' . $request->cari . '%')->get();
            // } else {
            //     $data = PeminjamanRuang::all();
            // }

            $data = $query->get();
            // dd($prodi);
            return view('user/data/peminjamanruang', [
                'data' => $data
            ]);
        }
    }

    public function create()
    {
        $prodi = Prodi::all();
        $ruang = Ruang::all();
        $jam = Jam::all();
        $matkul = MataKuliah::all();
        $dosen =  NamaDosen::all();
        $angkatan = Angkatan::all();
        return view('admin/peminjaman-ruang/create', [
            'title' => 'Tambah Peminjaman ruang',
            'ruang' => $ruang,
            'prodi' => $prodi,
            'jam_mulai' => $jam,
            'jam_selesai' => $jam,
            'matkul' => $matkul,
            'dosen' => $dosen,
            'angkatan' => $angkatan,
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_peminjam' => ['required'],
            'tgl_peminjaman' => ['required'],
            'ruang_id' => ['required', 'max:100'],
            'matkul_id' => ['required'],
            'dosen_id' => ['required'],
            'jam_mulai_id' => ['required'],
            'jam_selesai_id' => ['required'],
            'prodi_id' => ['required'],
            'angkatan_id' => ['required'],
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        // $nama_peminjam = $request->nama_peminjam;
        // $id = $request->id;
        // $cek = PeminjamanRuang::where('nama_peminjam', $nama_peminjam)
        //     ->where('status_peminjaman', 0)
        //     ->first();
        // $cekKesediaan = Ruang::where('id', $id)
        //     ->where('status_ruang', 0)->first();

        // if ($cek) {
        //     return redirect()->route('peminjaman-ruang.index')
        //         ->with('failed', 'Peminjam belum mengembalikan ruang sebelumnya!');
        // }
        // if ($cekKesediaan) {
        //     return redirect()->route('peminjaman-ruang.index')
        //         ->with('failed', 'Ruang tidak tersedia!');
        // }

        PeminjamanRuang::create($request->all());
        if (auth()->user()->type == '1') {
            Alert::success('Berhasil', 'Peminjaman Ruangan Berhasil Ditambahkan');
        } else {
            Alert::success('Berhasil', 'Peminjaman Ruangan Berhasil Ditambahkan');
        }

        if (auth()->user()->type == '1') {
            return redirect()->route('peminjaman-ruang.index')
                ->with('success', 'Peminjaman berhasil ditambahkan!');
        } else {
            return redirect()->route('user.home')
                ->with('success', 'Peminjaman berhasil ditambahkan!');
        }
    }

    public function edit($id)
    {
        $ruang = Ruang::all();
        $prodi = Prodi::all();
        $matkul = MataKuliah::all();
        $dosen = NamaDosen::all();
        $jam = Jam::all();
        $angkatan = Angkatan::all();
        $data = PeminjamanRuang::findOrFail($id);
        return view('admin/peminjaman-ruang/edit', [
            'title' => 'Ubah Peminjaman Ruang',
            'ruang' => $ruang,
            'prodi' => $prodi,
            'matkul' => $matkul,
            'dosen' => $dosen,
            'jam' => $jam,
            'angkatan' => $angkatan,
            'data' => $data,
        ]);
    }

    public function update(Request $request, $id)
    {
        $validated = Validator::make($request->all(), [
            'id' => 'required',
            'nama_peminjam' => 'required',
            'tgl_peminjaman' => 'required',
            'ruang_id' => 'required',
            'matkul_id' => 'required',
            'dosen_id' => 'required',
            'jam_mulai_id' => 'required',
            'jam_selesai_id' => 'required',
            'prodi_id' => 'required',
            'angkatan_id' => 'required',
        ]);

        $data = PeminjamanRuang::find($id);

        if ($request->status_peminjaman == 1) {
            $temp = Ruang::where('id', $request->id);
            $temp->update([
                'status_ruang' => 1
            ]);
        } else {
            $temp = Ruang::where('id', $request->id);
            $temp->update([
                'status_ruang' => 0
            ]);
        }
        $data->update($request->all());

        Alert::success('Berhasil', 'Peminjaman Ruangan Berhasil Diubah');

        return redirect()->route('peminjaman-ruang.index')
            ->with('success', 'Peminjaman berhasil diubah!');
    }

    public function destroy($id)
    {
        $data = PeminjamanRuang::findOrFail($id);
        $data->delete();

        Alert::success('Berhasil', 'Peminjaman Berhasil Dihapus');

        return redirect()->route('peminjaman-ruang.index')
            ->with('success', 'Peminjaman berhasil dihapus!');
    }
}
